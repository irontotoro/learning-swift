var count = 10
print(count)

var message="안녕"
print("message 변수의 값: " + message)

message="네, 안녕하세요"
print("message 변수의 값: " + message)

var sum : Int
sum=20
print(sum)

var title : String
title = "이영빈"
print(title)

var count2: Int=10
print(count2)

var school : String
school="스탠포드대학교"
print("학교명: " + school)

var isPerson = true
print(isPerson)

var isStudent : Bool
isStudent = false
print(isStudent)

var distance = 10.5
print(distance)

var time : Double
time = 20.4
print(time)
var pass1 : Character = "a"
var pass2 : Character
pass2 = "b"
print(pass1)

var maxValue : Int32 = Int32.max
var minValue : Int64 = Int64.min
print(maxValue)

var name1 :String = ""
var name2 = "안녕!"
print(name1)

var height : Double = 177
var weight : Double = 55    

var ratio : Double
ratio = height / weight

print("키/몸무게 비율")
print(ratio)

