func calcAge(name:String, mobile:String,birth:Int?)->(String,String,Int)?{
    if birth == nil{
        return nil
    }
    let age=2022 - birth! + 1
    return(name, mobile, age)
}
let person = calcAge(name: "김준수", mobile: "010-1000-1000", birth: 2004)
print("나이를 계산한 결과 ->\(person!.2)")
