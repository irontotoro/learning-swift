let userId = "test11"
let userPassword = "123456"

func login(id:String, password:String) -> Bool {
    if (id == userId) && (password == userPassword){
        return true
    }
    return false
}

var inputId = "test1"
var inputPassword = "123456"
var result = login(id:inputId, password:inputPassword)
print("아이디 확인결과 -> \(result)")

let a = 10
let b = 20
var c = 30
if(a + b) == c{
    print("값이 같습니다.")
}else {
    print("값이 다릅니다.")
}
let name:String? = "김현수"
let age:Int? = nil

if name == nil || age == nil{
    print("nil이 있습니다.")
} else {
    print("nil이 없습니다.")
}
//조건연산자는 조건을 주고 그다음에 ?기호를 붙인다. 만약 조건이 맞으면 ? 기호뒤에 있는 값을 변수에 할당합니다. 반대로 조건에 맞지 않으면 : 기호 뒤에 있는 값을 변수에 할당합니다.
var count = 10
var result1 = (count > 10) ? true : false
print("result 변수의 값 -> \(result1)")
 
var count2 = 20
var result2 : String? = (count2 > 20) ? "success" : nil

if result2 == nil {
    print("result2 변수의 값이 nil입니다.")
} else {
    print("result2 변수의 값 -> \(result2!)")
}
if count is Int {
    print("count 변수의 자료형은 Int 입니다.")
} else {
    print("count 변수의 자료형은 Int가 아닙니다.")
}

func sum(start:Int, end:Int) -> Int{
    var total = 0
    for i in start ..< end {
        total += i
    }
    return total
}
var result4 = sum(start: 1, end: 11)
print("sum(start:1, end:11)의 결과 -> \(result4)")
let start:Int = 200
let end:Int = 500
var total = 0
for i in start...end {
    total += i
}
print("200부터 500까지 더한 값 : \(total)")
func compare(value:Int) -> Int {
    if value < 0 {
        return -1
    } else if value == 0{
        return 0
    } else {
        return 1
    }
}
var result5 = compare(value: 10)
print("compare(value:10)의 결과 -> \(result5)")
func compare2(value:Int) -> Int{
    if value < 0 || value == 0 {
        return -1
    } else {
        return 1
    }
}
result5 = compare2(value: 10)
print("compare2(value:10)의 결과 -> \(result5)")

func compare3(value:Int) -> Int {
    if !(value < 0 || value == 0) {
        return -1
    } else {
        return 1
    }
}
result5 = compare3(value: 10)
print("compare3(value:10)의 결과 -> \(result5)")

let value:Int = 12
if value <= 10 {
    print("숫자 값이 10보다 작습니다")
} else {
    print("숫자 값이 10보다 큽니다")
}

func isMinor(old:Int) -> Bool{
    if old < 19 {
        return true
    } else {
        return false
    }
}
let old:Int = 20
let minor = isMinor(old: old)
print("미성년자 여부: \(minor)")
