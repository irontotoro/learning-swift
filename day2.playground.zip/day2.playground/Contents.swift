var v1 : Int = 10
var v2 : Int = 20
print(v1)

v1 = v2
print(v1)

var person1 :  String = "이영빈"
var person2 : String = "한가람"
person1 = person2
print("person1의 값 : " + person1)

var value1 : Int=10
var message : String="안녕"

var value2: String=String(value1)
print(message+value2)

var value3 : String = "20"
var value4 : Int? = Int(value3)
print(value4)
//Swift가 갖는 Optional이라는 개념은 변수의 값이 nil일 수 있다는 것을 표현하는 것, 반대로 Optional이 아니라면(non-optional) 해당 값은 nil이 될 수 없음을 의미.  Swift에서는 Optional은 선택적이며 기본값은 non-Optional 입니다. !을 쓰는 이유는 옵셔널안에 있는 값을 꺼내기 위해서이다
print(value4!)

var w : Double = 55
var weightStr = String(w)
var weight2 : Double? = Double(weightStr)
print("숫자 -> 문자열 -> 숫자로 형변환한 후의 몸무게 값")
print(weight2!)

let limit1 = 100
let limit2 : Int
limit2=200
print(limit1)
print(limit2)

typealias Feet = Int
var distance : Feet=3000
print(distance)
//typealias는 하나의 자료형을 다른이름으로 정의하는것 변수이름을 새로정의 할때 사용

print("사람","동물","집",separator: ",",terminator: "\n")
print("사람","동물","집",terminator: "")
var title = "즐거운 새해"
print("제목: \(title)")

var name : String = "이영빈"
var height : Double = 177
var weight : Double = 55

print("이름: \(name), 키: \(height), 몸무게: \(weight) ")

var name1 = "김준수"
var name2 = "나준수"
var name3 = "도준수"
var name4 = "라준수"

print("첫번째 사람: \(name1)")
print("두번째 사람: \(name2)")
print("세번째 사람: \(name3)")
print("네번째 사람: \(name4)")

let ageStr1 : String = "18"
let ageStr2 : String = "19"
let ageStr3 : String = "20"
let ageStr4 : String = "21"

var age1 : Int? = Int(ageStr1)
var age2 : Int? = Int(ageStr2)
var age3 : Int? = Int(ageStr3)
var age4 : Int? = Int(ageStr4)

print("나이: \(age1!), \(age2!), \(age3!), \(age4!)")

