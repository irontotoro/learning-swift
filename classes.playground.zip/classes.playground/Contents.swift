var count = 0
func add(a:Int, b:Int) -> Int {
    count += 1
    let output = a + b
    return output
}
func subtract(a:Int, b:Int)-> Int {
    count += 1
    return a-b
}
var result = add(a:20, b:10)
print("add 함수 호풀 후 -> \(result), \(count)")

result = subtract(a: 20, b: 10)
print("suvtract 함수 호출 후 -> \(result), \(count)")

class Calculator {
    var count = 0
    func add(a:Int, b:Int) -> Int {
        count += 1
        let output = a + b
        return output
    }
    func subtract(a:Int, b:Int)-> Int {
        count += 1
        return a-b
    }
    
}
var calculator1 = Calculator()
result = calculator1.add(a: 20, b: 10)
print("calculator1의 subtract 함수 호출 후 -> \(result), \(calculator1.count)")
 
class Dog {
    var name:String = "미미"
}
var dog1 = Dog()
print("강아지의 이름: \(dog1.name)")

class Person{
    var nameing:String?
    init() {
        
    }
    init(nameing:String){
        self.nameing = nameing
    }
    func walk(speed:Int){
        print("\(nameing)이(가) \(speed)km 속도로 걸어갑니다.")
    }
    func run(speed:Int){
        print("\(nameing)이(가) \(speed)km 속도로 뛰어갑니다.")
    }
}
var person01 = Person(nameing: "철수")
person01.walk(speed: 10)

var person02 = Person(nameing: "영희")
person02.walk(speed: 20)

var person03 = Person(nameing: "민희")
person03.walk(speed: 24)

var person04 = person03
person04.walk(speed: 30)

person03.nameing = "수진"
person04.walk(speed: 30)

func changePerson(person:Person){
    person.nameing = "진경"
}
changePerson(person: person03)
person04.walk(speed: 40)

if person01 === person02 {
    print("person01과 person02는 같습니다.")
} else {
    print("person01과 person02는 다릅니다.")
}

if person03 === person04 {
    print("person03과 person04는 같습니다.")
} else {
    print("persong03과 person04는 다릅니다.")
}
//===연산자-> 두객체가 같으면 true반환
//!==연산자-> 두객체가 다르면 true반환
