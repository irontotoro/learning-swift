func show(){
    print("안녕!")
}
show()
func showname(){
    let name: String = "이영빈"
    print("이름: \(name)")
}
showname()

func show2(){
    var count = 0
    count+=1
    count+=2
    count+=3
    count+=4
    count+=5
    count+=6
    count+=7
    count+=8
    count+=9
    count+=10
    print("1부터 10까지 더한결과 : \(count)")
}
show2()

func show3(){
    var count = 0
    for i in 1 ..< 11 {
        count+=i
    }
    print("1부터 10까지 더한결과 : \(count)")
}
show3()
func show4(){
    var count = 0
    for i in 1 ..< 11{
        count += i
    }
    print("1부터 10까지 더한결과 : \(count)")
    count=0
    for i in 1 ..< 101 {
        count+=i
    }
    print("1부터 100까지 더한결과: \(count)")
}
show4()

func sum(start:Int,end:Int)-> Int{
    var count = 0
    for i in start ..< end{
        count+=i
    }
    return count
}
var result = sum(start: 1, end: 11)
print("sum(1,11->\(result)")

result = sum(start: 1, end: 101)
print("sum(1,101)->\(result)")
//파라미터 전달의 원칙 func 함수이름 (파라미터1,파라미터2,파라미터n)-> 반환 자료형{}
//파라미터이름:자료형
//파라미터 이름이 하나면 내부와 외부 동시에 됨
//파라미터 이름 두개 쓰면 첫번째는 외부 두번째는 내부가 됨
//외부파라미터이름 내부파라미터이름 : 자료형
func add1(a:Int){
    print("add1 호출됨: \(a)")
}
add1(a:10)
func add2(a:Int,b:Int){
    print("add2 호출됨: \(a), \(b)")
}
add2(a: 10, b: 20)
func add3(first a : Int, second b:Int){
    print("add3 호출됨: \(a),\(b)")
}
add3(first:10,second: 20)

func add4( _ a:Int, _ b:Int){
    print("add4 호출됨 : \(a),\(b)")
}
add4(10,20)

func multiply( _ a:Int, _ b:Int)->Int{
    return a * b
}
let res = multiply(10,10)
print("곱하기결과: \(res)")

//파라미터 기본값정하기
func show(message:String, terminator:String="\n"){
    print("메시지 :\(message)",terminator: terminator)
}
show(message: "안녕!", terminator: "\n")
show(message:"안녕하세요!")
func show2(message:String,newline:Bool=true){
    print(message,newline)
}
show2(message: "반갑습니다.")

func add(a:Int,b:Int)->Int{
    return a + b
}
var r = add(a:10,b:10)
print("add 함수호출결과-> \(r)")

func add2( firstNum a:Int,secondNum b:Int)-> Int{
    return a + b
}
r=add2(firstNum: 20, secondNum: 20)
print("add2 함수 호출결과->\(r)")

func sum(values:Int ...)->Int{
    var total = 0
    for value in values {
        total += value
    }
    return total
}
var resul = sum(values:10,20,30,40,50)
print("sum 함수호출결과 -> \(resul)")
func show(message : String){
    print("전달받은메시지-> \(message)")
}
show(message:"안녕")
//파라미터 앞에 var 이나 let은 붙일수 없다 만약 하고싶다면 함수안에 변수를 새로 선언하고 그변수에 파라미터로 전달된 값을 넣자
func show2(message:inout String){
    print("전달 받은 메시지 -> \(message)")
    message="ok"
}
var greeting = "안녕하세요"
show2(message: &greeting)
print(greeting)
//함수정의했을때 파라미터 자료형 앞에 inout붙이기
//함수 호출시 전달하는 변수앞에&붙이기
func show2(value1:String){
    var value2 :Int?
    value2 = Int(value1)
    
    if value2 == nil {
        print("전달받은 값은 숫자가 아닙니다.")
    }else {
        print("전달받은 숫다 ->\(value2!)")
    }
}
show2(value1: "10")
show2(value1:"안녕!")

func show3(value1 : String)-> Int?{
    var value2 : Int?
    value2 = Int(value1)
    
    if value2 == nil{
        print("전달 받은 값은 숫자가 아닙니다.")
    } else {
        print("전달 받은 숫자 -> \(value2!)")
    }
    return value2
}
var reslt = show3(value1:"10")
print("show3 함수 호출 결과 -> \(reslt)")
//투플은 여러 개의 값을 하나로 묶어주는 자료형 투플에들어가는 값은 서로 다를수있음
//투플구조: 인덱스-변수명-변수값
let value1 = (10, "안녕",Float(2.4),true)
print("value1 투플의 값-> \(value1)")

var item1 = value1.0
print("value1 투플의 첫번째 원소 -> \(item1)")

let value2 = (x:10,y:20)
var item2 = value2.x
print("value2 투플의 x원소 -> \(item2)")

var value3 : (Int,Int) = (10,20)
value3.0 = 30
print("value3 투플의 첫번째 원소-> \(value3.0)")

let value4 : (Int,Int) = (10,10)
let (x, y) = value4
print("투플 안의 x값-> \(x)")

func getLocation()-> (x:Int, y:Int){
    return(10,10)
}
var location = getLocation()
print("내 위치 -> \(location.x),\(location.y)")

func getLocation2() -> (Int,Int){
    return(20,20)
}
print("내 위치 -> \(location)")

func getPerson(value1:String) -> (name:String, age:Int?)?{
    var value2 : Int?
    value2 = Int(value1)
    if value2 == nil {
        print("전달 받은 값은 숫자가 아닙니다.")
        return nil
    }else {
        print("전달 받은 숫자 -> \(value2!)")
        return(name:"김진수",age:value2)
    }
}

var rslt = getPerson(value1: "20")
print("getPerson 함수 호출 결과 -> \(rslt)")

func getCount(persons:(name:String, age:Int)...)-> Int{
    var count = 0
    for (_,_) in persons {
        count+=1
    }
    return count
}
var rslt2 = getCount(persons: ("김준수", 20),("나준수", 22))
print("getCount함수 호출 결과 -> \(rslt2)")
