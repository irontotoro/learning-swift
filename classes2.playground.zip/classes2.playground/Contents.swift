class Person {
    var name : String?
    var height : Float?
    var weight : Float?
    init(name:String,  height:Float, weight:Float){
        self.name = name
        self.height = height
        self.weight = weight
    }
    var bmi : Float = 0.0 {
        willSet(bmi){
            print("bmi")
        }
    }
}

var person01 = Person(name: "철수", height: 1.7, weight: 49.5)
print("BMI값 -> \(person01.bmi)")
person01.bmi = 18
print("BMI값 -> \(person01.bmi)")
person01.bmi = 22
print("BMI값 -> \(person01.bmi)")
